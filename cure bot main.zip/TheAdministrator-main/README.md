# TheAdministrator
This is the source code for a discord bot using discord.py v2.0 that is also mainly using app_commands and discord.Interactions.
__ __


<br>

# About
I decided to make this repo as a way for users working with the discord.py API to have a better and or easier time learnig how to work with certain elements, such as app commands, grouped commands, Modals, Buttons, Select menus, Events, and choice command options/drop downs. Since the discord.py documentation is kinda not the best when it comes to letting you know how to do something and not have it throw a million errors. (aka, showing examples with their information). So if you are a user who is trying to use discord.py, this repo is for you.

Feel free to use the code here as referance for some basic moderation commands, events, and more instead of spending hours googling.

<br>
<br>

Some additional notes;
  - I use `virtualenv` for where I install python libraries, so the code for updating packages have that as context and uses virtualenv.
  - Everything to the best of my ability uses discord.Interactions and app_commands, not "ctx" and prefix's.
  - More will be added here if needed.
__ __



<br>
<br>
<br>


# Support  |  Buy me a coffee <3
Donate to me here:
> - Don't have Cashapp? [Sign Up](https://cash.app/app/TKWGCRT)

![image](https://user-images.githubusercontent.com/45724082/158000721-33c00c3e-68bb-4ee3-a2ae-aefa549cfb33.png)
